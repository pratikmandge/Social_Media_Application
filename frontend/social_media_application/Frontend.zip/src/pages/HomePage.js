import React from 'react';

// import Navbar from '../components/common/Navbar';
import PostList from '../components/post/PostList';

const HomePage = () => {
  return (
      <PostList />
  );
};

export default HomePage;
