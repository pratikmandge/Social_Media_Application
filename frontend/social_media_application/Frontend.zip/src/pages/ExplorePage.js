import React from 'react';

function ExplorePage() {
  return (
    <div>
      <h1>Explore Page</h1>
      <p>This is the explore page.</p>
    </div>
  );
}

export default ExplorePage;
