import React from 'react';

export default function SearchPage() {
  return (
    <div>
      <h1>Search Page</h1>
      <p>This is the Search Page.</p>
    </div>
  );
}
