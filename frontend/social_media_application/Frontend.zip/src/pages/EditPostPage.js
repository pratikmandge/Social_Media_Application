import React from 'react';

export default function EditPostPage() {
  return (
    <div>
      <h1>EditPost Page</h1>
      <p>This is the EditPost Page.</p>
    </div>
  );
}
