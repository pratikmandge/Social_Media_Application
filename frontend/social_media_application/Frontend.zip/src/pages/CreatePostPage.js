import React from 'react';

export default function CreatePostPage() {
  return (
    <div>
      <h1>Create Post Page</h1>
      <p>This is the Create Post Page.</p>
    </div>
  );
}
