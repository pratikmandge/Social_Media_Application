import React from 'react';

export default function CreateMessagePage() {
  return (
    <div>
      <h1>Create Message Page</h1>
      <p>This is the Create Message Page.</p>
    </div>
  );
}
