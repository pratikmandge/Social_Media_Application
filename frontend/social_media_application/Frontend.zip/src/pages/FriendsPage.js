import React from 'react';

export default function FriendsPage() {
  return (
    <div>
      <h1>Friends Page</h1>
      <p>This is the Friends Page.</p>
    </div>
  );
}
