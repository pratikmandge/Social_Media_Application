import React from 'react';

export default function ViewMessagePage() {
  return (
    <div>
      <h1>View Message Page</h1>
      <p>This is the View Message Page.</p>
    </div>
  );
}
