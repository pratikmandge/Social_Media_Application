import React from 'react';

export default function ViewPostPage() {
  return (
    <div>
      <h1>View Post Page</h1>
      <p>This is the View Post Page.</p>
    </div>
  );
}
