import React from 'react';

export default function GroupsPage() {
  return (
    <div>
      <h1>Groups Page</h1>
      <p>This is the Groups Page.</p>
    </div>
  );
}
