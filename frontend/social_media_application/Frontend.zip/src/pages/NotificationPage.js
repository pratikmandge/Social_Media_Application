import React from 'react';

function NotificationPage() {
  return (
    <div>
      <h1>Notification Page</h1>
      <p>This is the Notification Page.</p>
    </div>
  );
}

export default NotificationPage;
